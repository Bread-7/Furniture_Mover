# Find Pythagorean Triple s.t. a + b + c = 1000, a < b < c

def findTriple():
    