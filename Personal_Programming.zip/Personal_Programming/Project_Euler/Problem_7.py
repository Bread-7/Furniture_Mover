# Find the 10001 prime

def nth_prime(n):
    max_val = 100000000
    primes = [True] * (max_val + 1)
    p = 2
    
    while p * p <= max_val:
        if primes[p]:
            for i in range(p * p, max_val + 1, p):
                primes[i] = False

        p += 1
    primes = [x for x in range(2, max_val + 1) if primes[x]]
    return primes[n - 1]

print(nth_prime(10001))