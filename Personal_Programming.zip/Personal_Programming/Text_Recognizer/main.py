import cv2
import numpy as np
import matplotlib.pyplot as plt

img = cv2.imread('image.jpg')
img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

found = cv2.CascadeClassifier()

plt.subplot(1, 1, 1)
plt.imshow(img_rgb)
plt.show()
# vid = cv2.VideoCapture(0)

# while True:
#     ret, frame = vid.read()
#     pass