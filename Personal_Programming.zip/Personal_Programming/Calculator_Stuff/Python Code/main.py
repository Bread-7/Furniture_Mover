import vectors as v
import matrices as m

q = [0] * 3
print(q == [0, 0, 0])

print('1. magnitude\n' +
        '2. crossProduct\n' +
        '3. dotProduct\n' +
        '4. angleBetweenVectors\n')
program = int(input())

if program == 0:
    print('5. pointOntoPlane\n' +
        '6. vectorOntoVector\n' +
        '7. pointOntoVector\n' +
        '8. rotate_x\n')
    program = int(input()) 
    if program == 0:
        print('9. rotate_y\n' +
            '10. rotate_z\n' +
            '11. determinant2D\n' +
            '12. determinant3D\n' +
            '13. eigen2D\n')
        program = int(input()) 

def str_to_list(string):
    return [float(i) for i in string.split(',')]

if program == 1:
    
    p = str_to_list(input('p:\n'))
    x = lambda s: [0] * len(p) if s == '' else str_to_list(s)
    q = x(input('q:\n'))
    print(v.magnitude(p, q))

if program == 2:
    U = str_to_list(input('U:\n'))
    V = str_to_list(input('V:\n'))
    print(v.crossProduct(U, V))

if program == 3:
    U = str_to_list(input('U:\n'))
    V = str_to_list(input('V:\n'))
    print(v.dotProduct(U, V))

if program == 4:
    U = str_to_list(input('U:\n'))
    V = str_to_list(input('V:\n'))
    print(v.angleBetweenVectors(U, V))

if program == 5:
    plane = str_to_list(input('plane:\n'))
    point = str_to_list(input('point:\n'))
    print(v.pointOntoPlane(plane, point))

if program == 6:
    U = str_to_list(input('U:\n'))
    V = str_to_list(input('V:\n'))
    print(v.vectorOntoVector(U, V))

if program == 7:
    vector = str_to_list(input('vector:\n'))
    vector_point = str_to_list(input('v_0:\n'))
    point = str_to_list(input('point:\n'))
    print(v.pointOntoVector(point, vector_point, vector))

if program == 8:
    theta = float(input('theta:\n'))
    point = str_to_list(input('point:\n'))
    print(m.rotate_x(theta, point))

if program == 9:
    theta = float(input('theta:\n'))
    point = str_to_list(input('point:\n'))
    print(m.rotate_y(theta, point))

if program == 10:
    theta = float(input('theta:\n'))
    point = str_to_list(input('point:\n'))
    print(m.rotate_z(theta, point))

if program == 11:
    matrix = str_to_list(input('2x2 matrix:\n'))
    print(m.determinant2D(matrix))

if program == 12:
    matrix = str_to_list(input('3x3 matrix:\n'))
    print(m.determinant3D(matrix))

if program == 13:
    matrix = str_to_list(input('2x2 matrix:\n'))
    print(m.eigen2D(matrix))