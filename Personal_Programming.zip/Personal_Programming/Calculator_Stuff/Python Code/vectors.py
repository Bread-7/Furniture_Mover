import math

def magnitude(p, q = [0, 0, 0]):    
    return math.sqrt(sum([(q[i] - p[i])**2 for i in range(len(p))]))

def crossProduct(u, v):
    return [u[1] * v[2] - u[2] * v[1],
         -(u[0] * v[2] - u[2] * v[0]),
         u[0] * v[1] - u[1] * v[0]]
    
def dotProduct(u, v):
    return sum([u[i] * v[i] for i in range(len(u))]) if len(u) == len(v) else None

def pointOntoPlane(plane, point):
    n = plane[:3]
    t = (plane[3] - dotProduct(n, point)) / dotProduct(n, n)
    return [point[i] + t * n[i] for i in range(len(n))]

def angleBetweenVectors(u, v):
    return math.acos(dotProduct(u, v) / (magnitude(p = u) * magnitude(p = v))) * 180.0 / math.pi

def vectorOntoVector(u, v):
    t = dotProduct(u, v) / magnitude(p = v)**2
    return [t * i for i in v]

def pointOntoVector(point, L1, L):
    v = [point[i] - L1[i] for i in range(len(L1))]
    v_proj = vectorOntoVector(v, L)
    return [L1[i] + v_proj[i] for i in range(len(L1))]