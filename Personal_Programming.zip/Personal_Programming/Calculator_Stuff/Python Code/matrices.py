import math
import vectors as v

def rotate_x(theta, point):
    theta *= math.pi / 180.0
    s = math.sin(theta)
    c = math.cos(theta)
    R = [[1, 0, 0],
         [0, c, -s],
         [0, s, c]]
    return [v.dotProduct(r, point) for r in R]

def rotate_y(theta, point):
    theta *= math.pi / 180.0
    s = math.sin(theta)
    c = math.cos(theta)
    R = [[c, 0, s],
         [0, 1, 0],
         [-s, 0, c]]
    return [v.dotProduct(r, point) for r in R]

def rotate_z(theta, point):
    theta *= math.pi / 180.0
    s = math.sin(theta)
    c = math.cos(theta)
    R = [[c, -s, 0],
         [s, c, 0],
         [0, 0, 1]]
    return [v.dotProduct(r, point) for r in R]

def determinant2D(matrix):
    u = matrix[:2]
    v = matrix[2:]
    return u[0] * v[1] - u[1] * v[0]

def determinant3D(matrix):
    r1 = matrix[:3]
    r2 = matrix[3:6]
    r3 = matrix[6:]
    prod = v.crossProduct(r2, r3)
    return sum([r1[i] * prod[i] for i in range(3)])

def eigen2D(matrix):
    a, b, c, d = matrix
    const = -(a + d)
    disc = math.sqrt(const**2 - 4 * (a * d - b * c))
    eigen_values = [(-const + (-1.0)**i * disc) / 2.0 for i in range(2)]
    return eigen_values
    
    # eigen_value1 = (-(a + d) + math.sqrt((a + d)**2 - 4 * (a * d - b * c))) / 2.0
    # eigen_value2 = (-(a + d) - math.sqrt((a + d)**2 - 4 * (a * d - b * c))) / 2.0
    # matrix1 = [[a - eigen_value1, b], [c, d - eigen_value1]]
    # matrix1_x = [[0, b], [0, d - eigen_value1]]
    # matrix1_y = [[a - eigen_value1, 0], [c, 0]]
    # matrix2 = [[a - eigen_value2, b], [c, d - eigen_value2]]
    # matrix2_x = [[0, b], [0, d - eigen_value2]]
    # matrix2_y = [[a - eigen_value2, 0], [c, 0]]
    # D1 = determinant2D(matrix1)
    # D1_x = determinant2D(matrix1_x)
    # D1_y = determinant2D(matrix1_y)
    # eigen_vector1 = [D1_x / D1, D1_y / D1]
    # D2 = determinant2D(matrix2)
    # D2_x = determinant2D(matrix2_x)
    # D2_y = determinant2D(matrix2_y)
    # eigen_vector2 = [D2_x / D2, D2_y / D2]
    # return {
    #     'eigen_values': [eigen_value1, eigen_value2],
    #     'eigen_vectors': [eigen_vector1, eigen_vector2]
    #     }