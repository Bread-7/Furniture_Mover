def level_1():
    f = open('input.txt', 'r')
    text = f.readlines() # 140 x 139
    new_text = text.copy()
    nums = {} # {num: [row, col, len]}
    specialChars = {}
    finalNums = []
    for lineCt, line in enumerate(text):
        for colCt, char in enumerate(line):
            if not char.isnumeric() and char != '.':
                # print(char, lineCt, colCt)
                specialChars[char + '_' + str(lineCt) + str(colCt)] = [lineCt, colCt]
    
    for char in specialChars:
        row, col = specialChars[char]
        new_str_left = text[row][:col]
        new_str_right = text[row][(col + 1):140]
        text[row] = new_str_left + '.' + new_str_right
    
    for lineCt, line in enumerate(text):
        split_line = [*line]
        print(split_line)
        for char in split_line:
            print('char', char)
            if char.isnumeric():
                nums[char + '_' + str(lineCt) + str(line.index(char))] = [lineCt, line.index(char), len(char)]
    
    max_iteration = {}
    for num in nums:
        y, x, length = nums[num]
        iteration = {}
        if y == 0:
            if x == 0:
                iteration[f'{y}'] = [x + length]
                iteration[f'{y + 1}'] = [col for col in range(x, x + length + 1, 1)]
            elif x + length == len(text[0]):
                iteration[f'{y}'] = [x - 1]
                iteration[f'{y + 1}'] = [col for col in range(x - 1, x + length, 1)]
            else:
                iteration[f'{y}'] = [x - 1, x + length]
                iteration[f'{y + 1}'] = [col for col in range(x - 1, x + length + 1, 1)]
        elif y == len(text) - 1:
            if x == 0:
                iteration[f'{y - 1}'] = [col for col in range(x - 1, x + length, 1)]
                iteration[f'{y}'] = [x + length]
            elif x + length == len(text[0]):
                iteration[f'{y - 1}'] = [col for col in range(x - 1, x + length, 1)]
                iteration[f'{y}'] = [x - 1]
            else:
                iteration[f'{y - 1}'] = [col for col in range(x - 1, x + length + 1, 1)]
                iteration[f'{y}'] = [x - 1, x + length]
        else:
            iteration[f'{y - 1}'] = [col for col in range(x - 1, x + length + 1, 1)]
            iteration[f'{y}'] = [x - 1, x + length]
            iteration[f'{y + 1}'] = [col for col in range(x - 1, x + length + 1, 1)]
        max_iteration[num] = iteration
    print('max_iteration', max_iteration)
    specialCharsCoords = [coord for coord in specialChars.values()]
    lastrow = lastcol = 0
    print(specialCharsCoords)
    for num in max_iteration:
        for row in max_iteration[num]:
            if int(row) != -1 and int(row) != len(text):
                for col in max_iteration[num][row]:
                    #  and int(col) != (len(text[0]) - 1)
                    if int(col) != -1 and [int(row), int(col)] in specialCharsCoords:
                        i = specialCharsCoords.index([int(row), int(col)])
                        y, x = specialCharsCoords[i]
                        print(int(row), int(col), specialCharsCoords.index([int(row), int(col)]))
                        new_num = int(num.split('_')[0])
                        print('special char', new_text[y][x], '\n', 'visible num', new_num, '\n')
                        print('visible num', new_num)
                        finalNums.append(new_num)
                    lastcol = int(col)
            lastrow = int(row)
    # print('last char', new_text[lastrow - 1][lastcol + 1])
    print('final nums', finalNums)
    # print('coords length', len(specialCharsCoords))
    return sum(finalNums)
    
a = level_1()
print('final sum', a)