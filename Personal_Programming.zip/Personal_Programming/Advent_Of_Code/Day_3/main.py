def level_1():
    f = open('input.txt', 'r')
    text = f.readlines()
    for lineCt in range(len(text)):
        text[lineCt] = text[lineCt].rstrip('\n')
    new_text = {}
    for lineCt, line in enumerate(text):
        split_line = [*line]
        new_text[f'line_{lineCt}'] = ['']
        for char in split_line:
            if char.isdigit():
                arr = new_text[f'line_{lineCt}']
                if not new_text[f'line_{lineCt}'][len(arr) - 1].isdigit():
                    new_text[f'line_{lineCt}'].append(char)
                else:
                    new_text[f'line_{lineCt}'][len(arr) - 1] += char
            if char == '.':
                new_text[f'line_{lineCt}'].append('.')
            if not (char.isnumeric()) and not (char == '.'):
                new_text[f'line_{lineCt}'].append(char)
        
    for key in new_text.keys():
        new_text[key].pop(0)

    nums = {}
    for lineNum, key in enumerate(new_text):
        startingCol = 0
        prevStr = ''
        line = new_text[key]
        for item in line:
            startingCol = len(prevStr)
            prevStr += item
            if item.isnumeric():
                nums[f'{item}_{lineNum};{startingCol}'] = [lineNum, startingCol, len(item)]

    chars_coords = {}
    for num in nums:
        coords = []
        row, col, length = nums[num]
        coords.extend([[row - 1, c] for c in range(col - 1, col + length + 1, 1) if row > 0 and c != -1 ])
        coords.extend([[row, c] for c in [col - 1, col + length] if c != -1 and c < len(text[0])])
        coords.extend([[row + 1, c] for c in range(col - 1, col + length + 1, 1) if c != -1 and row < len(text) - 1])
        chars_coords[num] = coords

    special_chars = {}
    for lineCt, line in enumerate(text):
        split_line = [*line]
        for charCt, char in enumerate(split_line):
            if not char.isnumeric() and char != '.':
                special_chars[f'{char}_{lineCt};{charCt}'] = [lineCt, charCt]
    finalNums = []
    for char in special_chars:
        for coord in chars_coords:
            coord_list = chars_coords[coord]
            if special_chars[char] in coord_list:
                splitNumStr = coord.split('_')[0]
                splitNumInt = int(splitNumStr)
                finalNums.append(splitNumInt)

    return sum(finalNums)
   
   
def level_2():
    f = open('input.txt', 'r')
    text = f.readlines()
    for lineCt in range(len(text)):
        text[lineCt] = text[lineCt].rstrip('\n')
    new_text = {}
    for lineCt, line in enumerate(text):
        split_line = [*line]
        new_text[f'line_{lineCt}'] = ['']
        for char in split_line:
            if char.isdigit():
                arr = new_text[f'line_{lineCt}']
                if not new_text[f'line_{lineCt}'][len(arr) - 1].isdigit():
                    new_text[f'line_{lineCt}'].append(char)
                else:
                    new_text[f'line_{lineCt}'][len(arr) - 1] += char
            if char == '.':
                new_text[f'line_{lineCt}'].append('.')
            if not (char.isnumeric()) and not (char == '.'):
                new_text[f'line_{lineCt}'].append(char)
        
    for key in new_text.keys():
        new_text[key].pop(0)
    
    nums = {}
    for lineNum, key in enumerate(new_text):
        startingCol = 0
        prevStr = ''
        line = new_text[key]
        for item in line:
            startingCol = len(prevStr)
            prevStr += item
            if item.isnumeric():
                nums[f'{item}_{lineNum};{startingCol}'] = [lineNum, startingCol, len(item)]
    
    num_coords = {}
    for num in nums:
        row, col, length = nums[num]
        num_coords[num] = [[row, c] for c in range(col, col + length)]

    special_chars = {}
    for lineCt, line in enumerate(text):
        split_line = [*line]
        for charCt, char in enumerate(split_line):
            if char == '*':
                special_chars[f'{char}_{lineCt};{charCt}'] = []
                special_chars[f'{char}_{lineCt};{charCt}'].extend([[lineCt - 1, c] for c in range(charCt - 1, charCt + 2, 1)])
                special_chars[f'{char}_{lineCt};{charCt}'].extend([[lineCt, charCt - 1], [lineCt, charCt + 1]])
                special_chars[f'{char}_{lineCt};{charCt}'].extend([[lineCt + 1, c] for c in range(charCt - 1, charCt + 2, 1)])
    
    finalNums = []
    for char in special_chars:
        special_char = special_chars[char]
        num1 = num2 = 0
        for spec in special_char:
            for key in num_coords:
                coords = num_coords[key]
                if spec in coords:
                    splitNumInt = int(key.split('_')[0])
                    num1 = splitNumInt if num1 == 0 and num2 == 0 else num1
                    num2 = splitNumInt if num1 != 0 and num2 == 0 and splitNumInt != num1 else num2
        finalNums.append(num1 * num2)

    return sum(finalNums)

a = level_2()
print(a)