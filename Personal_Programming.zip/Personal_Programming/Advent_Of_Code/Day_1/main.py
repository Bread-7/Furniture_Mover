import re

def level_1():
    f = open('input.txt', 'r')
    sumArr = []
    for i in f.readlines():
        tempStr = i
        strArr = [*tempStr]
        strArr.sort()
        numDict = {} # num: index
        for val in strArr:
            if val.isnumeric():
                numDict[val] = [x for x, ltr in enumerate(tempStr) if ltr == val]
        indices = []
        for vals in numDict.values():
            indices.extend(vals)
        indices.sort()
        num1 = tempStr[indices[0]]
        num2 = tempStr[indices[len(indices) - 1]]
        finalStr = (num1 + num2) if tempStr.index(num1) < tempStr.index(num2) else (num2 + num1)
        finalNum = int(finalStr)
        sumArr.append(finalNum)

    # print(len(sumArr))
    return sum(sumArr)

def level_2():
    nums = ['one', 'two', 'three', 'four', 'five',
            'six', 'seven', 'eight', 'nine']
    f = open('input.txt', 'r')
    sumArr = []
    for i in f.readlines():
        indices = []
        numDict = {}
        index = 0
        for num in nums:
            [m.start() for m in re.finditer(num, i)]
            numDict[str(index + 1)] = [m.start() for m in re.finditer(str(index + 1), i)]
            numDict[str(index + 1)].extend([m.start() for m in re.finditer(num, i)])
            index += 1
        for key in numDict:
            if len(numDict[key]) == 0:
                continue
            else:
                indices.extend(numDict[key])
        indices.sort()
        minStr = maxStr = ''
        for key in numDict:
            if indices[0] in numDict[key]:
                minStr = key
            if indices[len(indices) - 1] in numDict[key]:
                maxStr = key
        finalStr = minStr + maxStr
        sumArr.append(int(finalStr))
    return sum(sumArr)

a = level_2()
print(a)