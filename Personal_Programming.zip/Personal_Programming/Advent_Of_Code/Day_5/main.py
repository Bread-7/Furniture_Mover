def level_1():
    f = open('input.txt', 'r')
    text = f.readlines()
    for i in range(len(text)):
        text[i] = text[i].rstrip('\n')
    
    map_dict = {}
    seeds = [int(i) for i in text[0].split() if i.isnumeric()]
    text = text[2:]

    map_dict = {}
    last_str = ''

    for line in text:
        if line.__contains__('map:'):
            last_str = line.split()[0]
            map_dict[last_str] = []
        elif line == '':
            continue
        else:
            map_dict[last_str].extend([[int(i) for i in line.split()]])

    locations = []
    for seed in seeds:
        last_input = seed
        for map in map_dict:
            for coord in map_dict[map]:
                output_start, input_start, delta = coord
                if input_start <= last_input < input_start + delta:
                    last_input += output_start - input_start
                    break
            
        locations.append(last_input)
    
    return min(locations)


def level_2():
    f = open('input.txt', 'r')
    text = f.readlines()
    for i in range(len(text)):
        text[i] = text[i].rstrip('\n')
    
    map_dict = {}
    old_seeds = [int(i) for i in text[0].split() if i.isnumeric()]
    seeds = []
    for i in range(0, len(old_seeds), 2):
        seeds.extend([old_seeds[i] + x for x in range(old_seeds[i + 1])])
    
    text = text[2:]

    map_dict = {}
    last_str = ''

    for line in text:
        if line.__contains__('map:'):
            last_str = line.split()[0]
            map_dict[last_str] = []
        elif line == '':
            continue
        else:
            map_dict[last_str].extend([[int(i) for i in line.split()]])

    locations = []
    for seed in seeds:
        last_input = seed
        for map in map_dict:
            for coord in map_dict[map]:
                output_start, input_start, delta = coord
                if last_input >= input_start and last_input < input_start + delta:
                    last_input += output_start - input_start
                    break
    
        locations.append(last_input)
    
    return min(locations)


a = level_2()
print(a)