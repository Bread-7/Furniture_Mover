import math

def level_1():
    f = open('input.txt', 'r')
    text = f.readlines()
    inputs = [*text[0].rstrip('\n').replace('L', '0').replace('R', '1')]
    network_dict = {}
    
    for i in range(2, len(text), 1):
        key, val = text[i].rstrip('\n').split(' = ')
        val = val[1:-1].split(', ')
        network_dict[key] = val

    last_key = 'AAA'
    count = index = 0
    while last_key != 'ZZZ':
        count += 1
        index %= len(inputs)
        last_key = network_dict[last_key][int(inputs[index])]
        index += 1
    
    return count

def level_2():
    f = open('input.txt', 'r')
    text = f.readlines()
    inputs = [*text[0].rstrip('\n').replace('L', '0').replace('R', '1')]
    network_dict = {}
    
    keys = []
    for i in range(2, len(text), 1):
        key, val = text[i].rstrip('\n').split(' = ')
        val = val[1:-1].split(', ')
        network_dict[key] = val
        if key[-1] == 'A':
            keys.append(key)
    
    # print(keys)
    
    # last_key = 'AAA'
    count = index = 0
    final_chars = []
    # for i in range(len(keys)):
    #     count += 1
    #     index %= len(inputs)
    length = len(keys)
    arr = keys
    while final_chars != ['Z'] * length:
        count += 1
        index %= len(inputs)
        # print('1', keys)
        keys = map(lambda x: network_dict[x][int(inputs[index])], arr)
        arr = list(keys)
        # print(arr)
        # keys = [network_dict[keys[i]][int(inputs[index])] for i in range(len(keys))]
        # print('2', keys)
        # final_chars = [key[-1] for key in arr]
        # print(final_chars)
        # print(final_chars, keys)
        index += 1

    # while last_key != 'ZZZ':
    #     count += 1
    #     index %= len(inputs)
    #     last_key = network_dict[last_key][int(inputs[index])]
    #     index += 1
    
    return count

a = level_2()
print(a)