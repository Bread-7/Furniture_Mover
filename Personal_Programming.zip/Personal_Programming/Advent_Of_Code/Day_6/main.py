import math

def level_1():
    f = open('input.txt', 'r')
    text = f.readlines()
    for i in range(len(text)):
        text[i] = text[i].rstrip('\n')
    
    time_dict = {}
    
    time_line = text[0].split(':')
    dist_line = text[1].split(':')

    time_dict[time_line[0]] = time_line[1].split()
    time_dict[dist_line[0]] = dist_line[1].split()

    for key in time_dict:
        for i in range(len(time_dict[key])):
            time_dict[key][i] = int(time_dict[key][i])
    
    
    time, dist = list(time_dict.values())
    prod = 1
    for i in range(len(time)):
        x_lower = (time[i] - math.sqrt(time[i] ** 2 - 4 * 1 * dist[i])) / 2.0
        x_upper = (time[i] + math.sqrt(time[i] ** 2 - 4 * 1 * dist[i])) / 2.0
        prod *= (int(x_upper) - int(x_lower))
            
    return prod

def level_2():
    f = open('input.txt', 'r')
    text = f.readlines()
    for i in range(len(text)):
        text[i] = text[i].rstrip('\n')
    
    time_dict = {}
    
    time_line = text[0].split(':')
    dist_line = text[1].split(':')

    time_dict[time_line[0]] = time_line[1].split()
    time_dict[dist_line[0]] = dist_line[1].split()

    time, dist = list(time_dict.values())
    new_time = new_dist = ''
    for i in range(len(time)):
        new_time += time[i]
        new_dist += dist[i]

    new_time = int(new_time)
    new_dist = int(new_dist)
    
    x_lower = (new_time - math.sqrt(new_time ** 2 - 4 * 1 * new_dist)) / 2.0
    x_upper = (new_time + math.sqrt(new_time ** 2 - 4 * 1 * new_dist)) / 2.0
    
    return int(x_upper) - int(x_lower)
    

a = level_2()
print(a)