def level_1():
    f = open('input.txt', 'r')
    text = f.readlines()

    score = 0
    for lineCt in range(len(text)):
        text[lineCt] = text[lineCt].rstrip('\n')
        winningNumsCt = 0
        allNums = text[lineCt].split(': ')[1]
        winningNums, myNums = allNums.split(' | ')
        winningNums = winningNums.split()
        myNums = myNums.split()
        for winningNum in winningNums:
            if winningNum in myNums:
                winningNumsCt += 1
        score = score + 2 ** (winningNumsCt - 1) if winningNumsCt > 0 else score
    
    return score
    
def level_2():
    f = open('input.txt', 'r')
    text = f.readlines()

    card_dict = {}
    for lineCt in range(len(text)):
        text[lineCt] = text[lineCt].rstrip('\n')
        winningNumsCt = 0
        allNums = text[lineCt].split(': ')[1]
        winningNums, myNums = allNums.split(' | ')
        winningNums = winningNums.split()
        myNums = myNums.split()
        for winningNum in winningNums:
            if winningNum in myNums:
                winningNumsCt += 1
        card_dict[f'{lineCt}'] = winningNumsCt
    
    card_counts_dict = {}
    for i in range(len(text)):
        card_counts_dict[f'{i}'] = 1
    
    for card in card_dict:
        for i in range(1, card_dict[card] + 1, 1):
            card_counts_dict[f'{int(card) + i}'] += card_counts_dict[card]
            
    return sum(list(card_counts_dict.values()))

a = level_2()
print(a)