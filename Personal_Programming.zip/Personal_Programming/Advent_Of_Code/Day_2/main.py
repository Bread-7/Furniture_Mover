def level_1():
    f = open('input.txt', 'r')
    max_dict = {'red': 12, 'green': 13, 'blue': 14}
    sumArr = []
    for line in f.readlines():
        game_set_split = line.split(': ')
        game_num = int(game_set_split[0].split('Game ')[1])
        sets = game_set_split[1].split('; ')
        enoughBalls = True
        for set in sets:
            subsets = set.split(', ')
            for subset in subsets:
                balls = subset.split()
                if int(balls[0]) > max_dict[balls[1]]:
                    enoughBalls = False
        if(enoughBalls):
            sumArr.append(game_num)
    return sum(sumArr)

def level_2():
    f = open('input.txt', 'r')
    max_dict = {'red': 12, 'green': 13, 'blue': 14}
    sumArr = []
    for line in f.readlines():
        color_dict = {'red': [], 'green': [], 'blue': []}
        power = 1
        game_set_split = line.split(': ')
        sets = game_set_split[1].split('; ')
        for set in sets:
            subsets = set.split(', ')
            for subset in subsets:
                balls = subset.split()
                color_dict[balls[1]].append(int(balls[0]))
        for color in color_dict:
            power *= max(color_dict[color])
        sumArr.append(power)
    return sum(sumArr)

a = level_2()
print(a)