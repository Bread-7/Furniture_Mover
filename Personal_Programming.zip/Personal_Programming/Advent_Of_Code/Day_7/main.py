def level_1():
    f = open('input.txt', 'r')
    text = f.readlines()
    card_order = [f'{i}' for i in range(2, 10, 1)]
    card_order.extend(['T', 'J', 'Q', 'K', 'A'])
    hand_order = [a + b + c + d + e for a in card_order for b in card_order for c in card_order for d in card_order for e in card_order]

    card_dict = {'high_card': [], 'one_pair': [], 
                 'two_pair': [], 'three_kind': [],
                 'full_house': [], 'four_kind': [],
                 'five_kind': []
                 }
    
    card_list = ['five_kind', ['four_kind', 'full_house'], 
                 ['three_kind', 'two_pair'], 'one_pair', 'high_card']
    
    rank_list = []

    for i in range(len(text)):
        text[i] = text[i].rstrip('\n')
        hand, bid = text[i].split()
        card_amts = [hand.count(card) for card in set(hand)]
        hand_str = card_list[len(card_amts) - 1]

        if isinstance(hand_str, list):
            if len(card_amts) == 2:
                hand_str = hand_str[0] if 4 in card_amts else hand_str[1]
            if len(card_amts) == 3:
                hand_str = hand_str[1] if 2 in card_amts else hand_str[0]

        card_dict[hand_str].append([hand, bid])

    for key in card_dict:
        if card_dict[key] != []:
            hands = {}
            for pair in card_dict[key]:
                hand, bid = pair
                hands[hand] = bid
            arr = sorted(list(hands.keys()), key = lambda x: hand_order.index(x))
            for hand in arr:
                rank_list.append(int(hands[hand]))
    sum = 0
    for rank, bid in enumerate(rank_list):
        sum += bid * (rank + 1)
    
    return sum
        
a = level_1()
print(a)